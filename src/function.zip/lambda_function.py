import mylinebot

def lambda_handler(event, context):
    return mylinebot.lambda_handler(event, context)
