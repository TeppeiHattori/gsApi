import os
import logging
from linebot import LineBotApi, WebhookHandler
from linebot.models import MessageEvent, TextMessage, TextSendMessage
from linebot.exceptions import InvalidSignatureError

# 環境変数の取得
channel_secret = os.getenv('LINE_CHANNEL_SECRET')
channel_access_token = os.getenv('LINE_CHANNEL_ACCESS_TOKEN')

# ロギング設定
logging.basicConfig(level=logging.INFO)

if channel_secret is None:
    logging.error('LINE_CHANNEL_SECRET is None')
if channel_access_token is None:
    logging.error('LINE_CHANNEL_ACCESS_TOKEN is None')

handler = WebhookHandler(channel_secret)
line_bot_api = LineBotApi(channel_access_token)

def lambda_handler(event, context):
    logging.info('Event: %s', event)
    headers = event["headers"]
    body = event["body"]

    # get X-Line-Signature header value
    signature = headers['x-line-signature']

    # handle webhook body
    try:
        handler.handle(body, signature)
    except InvalidSignatureError:
        logging.error('Invalid signature. Check your channel access token/channel secret.')
        return {"statusCode": 400, "body": "Invalid signature. Please check your channel access token/channel secret."}

    return {"statusCode": 200, "body": "OK"}

@handler.add(MessageEvent, message=TextMessage)
def handle_text_message(event):
    """ TextMessage handler """
    input_text = event.message.text
    logging.info('Received message: %s', input_text)

    line_bot_api.reply_message(
        event.reply_token,
        TextSendMessage(text=input_text))
